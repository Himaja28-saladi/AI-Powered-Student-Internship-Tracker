/**
 * ============================================================
 *   INTERNSHIP TRACKER — BACKEND SERVER
 *   Pure Node.js | No npm required | File-based JSON storage
 * ============================================================
 */

const http    = require('http');
const fs      = require('fs');
const path    = require('path');
const crypto  = require('crypto');
const url     = require('url');

const PORT    = 3000;
const DB_DIR  = path.join(__dirname, 'data');
const SECRET  = 'internship_tracker_jwt_secret_2024';

// ── Ensure data directory exists ──────────────────────────
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

// ── Simple JSON file database ─────────────────────────────

function readDB(name) {
  const file = path.join(DB_DIR, `${name}.json`);
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; }
}

function writeDB(name, data) {
  fs.writeFileSync(path.join(DB_DIR, `${name}.json`), JSON.stringify(data, null, 2));
}

function readKV(name) {
  const file = path.join(DB_DIR, `${name}.json`);
  if (!fs.existsSync(file)) return {};
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}

function writeKV(name, data) {
  fs.writeFileSync(path.join(DB_DIR, `${name}.json`), JSON.stringify(data, null, 2));
}

// ── Seed default admin & student if not exist ─────────────
function seedUsers() {
  const users = readDB('users');
  if (!users.find(u => u.role === 'admin')) {
    users.push({
      id: uid(), email: 'admin', password: hashPassword('1234'),
      role: 'admin', name: 'Administrator', createdAt: now()
    });
  }
  if (!users.find(u => u.role === 'student' && u.email === 'student@college.edu')) {
    users.push({
      id: uid(), email: 'student@college.edu', password: hashPassword('student123'),
      role: 'student', name: 'Demo Student', createdAt: now()
    });
  }
  writeDB('users', users);
}

// ── Helpers ───────────────────────────────────────────────

function uid()        { return crypto.randomBytes(8).toString('hex'); }
function now()        { return new Date().toISOString(); }

function hashPassword(pw) {
  return crypto.createHmac('sha256', SECRET).update(pw).digest('hex');
}

function signToken(payload) {
  const header  = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body    = b64url(JSON.stringify({ ...payload, iat: Date.now() }));
  const sig     = b64url(crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest());
  return `${header}.${body}.${sig}`;
}

function verifyToken(token) {
  try {
    const [header, body, sig] = token.split('.');
    const expected = b64url(crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest());
    if (sig !== expected) return null;
    return JSON.parse(Buffer.from(body, 'base64url').toString());
  } catch { return null; }
}

function b64url(data) {
  if (typeof data === 'string') return Buffer.from(data).toString('base64url');
  return data.toString('base64url');
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function send(res, status, data) {
  const json = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type':  'application/json',
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Content-Length': Buffer.byteLength(json)
  });
  res.end(json);
}

function auth(req) {
  const h = req.headers['authorization'] || '';
  const token = h.replace('Bearer ', '').trim();
  return verifyToken(token);
}

function serveFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = {
    '.html': 'text/html',
    '.css':  'text/css',
    '.js':   'text/javascript',
    '.json': 'application/json',
    '.png':  'image/png',
    '.jpg':  'image/jpeg',
    '.ico':  'image/x-icon',
  }[ext] || 'text/plain';

  if (!fs.existsSync(filePath)) {
    // Fall back to index.html for SPA
    const index = path.join(__dirname, 'public', 'index.html');
    if (fs.existsSync(index)) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(fs.readFileSync(index));
    } else {
      res.writeHead(404);
      res.end('Not found');
    }
    return;
  }
  res.writeHead(200, { 'Content-Type': mime });
  res.end(fs.readFileSync(filePath));
}

// ── Router ────────────────────────────────────────────────

async function router(req, res) {
  const parsed   = url.parse(req.url, true);
  const pathname = parsed.pathname;
  const method   = req.method;

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    });
    return res.end();
  }

  // ── Static files ──
  if (!pathname.startsWith('/api/')) {
    const safePath = pathname === '/' ? '/index.html' : pathname;
    return serveFile(res, path.join(__dirname, 'public', safePath));
  }

  // ── API Routes ──

  try {

    // ── AUTH ──────────────────────────────────────────────

    // POST /api/auth/login
    if (pathname === '/api/auth/login' && method === 'POST') {
      const { email, password } = await readBody(req);
      const users = readDB('users');
      const user  = users.find(u => u.email === email && u.password === hashPassword(password));
      if (!user) return send(res, 401, { error: 'Invalid credentials' });
      const token = signToken({ id: user.id, email: user.email, role: user.role, name: user.name });
      return send(res, 200, { token, user: { id: user.id, email: user.email, role: user.role, name: user.name } });
    }

    // POST /api/auth/register (student self-register)
    if (pathname === '/api/auth/register' && method === 'POST') {
      const { email, password, name } = await readBody(req);
      if (!email || !password || !name) return send(res, 400, { error: 'All fields required' });
      const users = readDB('users');
      if (users.find(u => u.email === email)) return send(res, 409, { error: 'Email already exists' });
      const newUser = { id: uid(), email, password: hashPassword(password), role: 'student', name, createdAt: now() };
      users.push(newUser);
      writeDB('users', users);
      const token = signToken({ id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name });
      return send(res, 201, { token, user: { id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name } });
    }

    // GET /api/auth/me
    if (pathname === '/api/auth/me' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      return send(res, 200, { user });
    }

    // ── INTERNSHIPS ───────────────────────────────────────

    // GET /api/internships
    if (pathname === '/api/internships' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const all = readDB('internships');
      const list = user.role === 'admin' ? all : all.filter(i => i.userId === user.id);
      return send(res, 200, list);
    }

    // POST /api/internships
    if (pathname === '/api/internships' && method === 'POST') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const body = await readBody(req);
      if (!body.name || !body.company) return send(res, 400, { error: 'Name and company required' });
      const item = {
        id: uid(), userId: user.id, userEmail: user.email,
        name: body.name, company: body.company,
        start: body.start || '', end: body.end || '',
        status: body.status || 'Ongoing',
        notes: body.notes || '',
        createdAt: now(), updatedAt: now()
      };
      const all = readDB('internships');
      all.push(item);
      writeDB('internships', all);
      return send(res, 201, item);
    }

    // PUT /api/internships/:id
    const putIntern = pathname.match(/^\/api\/internships\/([a-f0-9]+)$/);
    if (putIntern && method === 'PUT') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const body = await readBody(req);
      const all  = readDB('internships');
      const idx  = all.findIndex(i => i.id === putIntern[1] && (i.userId === user.id || user.role === 'admin'));
      if (idx === -1) return send(res, 404, { error: 'Not found' });
      all[idx] = { ...all[idx], ...body, id: all[idx].id, userId: all[idx].userId, updatedAt: now() };
      writeDB('internships', all);
      return send(res, 200, all[idx]);
    }

    // DELETE /api/internships/:id
    const delIntern = pathname.match(/^\/api\/internships\/([a-f0-9]+)$/);
    if (delIntern && method === 'DELETE') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      if (user.role !== 'admin') return send(res, 403, { error: 'Admin only' });
      const all = readDB('internships');
      const filtered = all.filter(i => i.id !== delIntern[1]);
      if (filtered.length === all.length) return send(res, 404, { error: 'Not found' });
      writeDB('internships', filtered);
      return send(res, 200, { message: 'Deleted' });
    }

    // ── PROFILES ──────────────────────────────────────────

    // GET /api/profile
    if (pathname === '/api/profile' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const profiles = readDB('profiles');
      const profile  = profiles.find(p => p.userId === user.id);
      return send(res, 200, profile || {});
    }

    // PUT /api/profile
    if (pathname === '/api/profile' && method === 'PUT') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const body = await readBody(req);
      const profiles = readDB('profiles');
      const idx = profiles.findIndex(p => p.userId === user.id);
      const updated = { ...body, userId: user.id, updatedAt: now() };
      if (idx === -1) profiles.push(updated);
      else profiles[idx] = updated;
      writeDB('profiles', profiles);
      return send(res, 200, updated);
    }

    // ── NOTES ─────────────────────────────────────────────

    // GET /api/notes
    if (pathname === '/api/notes' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const notes = readDB('notes');
      return send(res, 200, notes.filter(n => n.userId === user.id));
    }

    // POST /api/notes
    if (pathname === '/api/notes' && method === 'POST') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const { content } = await readBody(req);
      const notes = readDB('notes');
      const idx = notes.findIndex(n => n.userId === user.id);
      const note = { userId: user.id, content: content || '', updatedAt: now() };
      if (idx === -1) notes.push(note);
      else notes[idx] = note;
      writeDB('notes', notes);
      return send(res, 200, note);
    }

    // ── CALENDAR ──────────────────────────────────────────

    // GET /api/calendar
    if (pathname === '/api/calendar' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const cals = readDB('calendar');
      return send(res, 200, cals.find(c => c.userId === user.id) || {});
    }

    // POST /api/calendar
    if (pathname === '/api/calendar' && method === 'POST') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const body = await readBody(req);
      const cals = readDB('calendar');
      const idx  = cals.findIndex(c => c.userId === user.id);
      const cal  = { userId: user.id, ...body, updatedAt: now() };
      if (idx === -1) cals.push(cal); else cals[idx] = cal;
      writeDB('calendar', cals);
      return send(res, 200, cal);
    }

    // ── NOTICES (Admin) ───────────────────────────────────

    // GET /api/notices
    if (pathname === '/api/notices' && method === 'GET') {
      const kv = readKV('notices');
      return send(res, 200, { notice: kv.notice || '' });
    }

    // POST /api/notices
    if (pathname === '/api/notices' && method === 'POST') {
      const user = auth(req);
      if (!user || user.role !== 'admin') return send(res, 403, { error: 'Admin only' });
      const { notice } = await readBody(req);
      writeKV('notices', { notice, updatedAt: now() });
      return send(res, 200, { notice });
    }

    // ── ADMIN: All Users ──────────────────────────────────

    // GET /api/admin/users
    if (pathname === '/api/admin/users' && method === 'GET') {
      const user = auth(req);
      if (!user || user.role !== 'admin') return send(res, 403, { error: 'Admin only' });
      const users = readDB('users').map(u => ({ id: u.id, email: u.email, role: u.role, name: u.name, createdAt: u.createdAt }));
      return send(res, 200, users);
    }

    // ── STATS ─────────────────────────────────────────────

    // GET /api/stats
    if (pathname === '/api/stats' && method === 'GET') {
      const user = auth(req);
      if (!user) return send(res, 401, { error: 'Unauthorized' });
      const all = readDB('internships');
      const mine = user.role === 'admin' ? all : all.filter(i => i.userId === user.id);
      return send(res, 200, {
        total:     mine.length,
        completed: mine.filter(i => i.status === 'Completed').length,
        ongoing:   mine.filter(i => i.status === 'Ongoing').length,
      });
    }

    // 404
    send(res, 404, { error: 'Route not found' });

  } catch (err) {
    console.error('Server error:', err);
    send(res, 500, { error: 'Internal server error' });
  }
}

// ── Start ─────────────────────────────────────────────────

seedUsers();
const server = http.createServer(router);

server.listen(PORT, () => {
  console.log('\n');
  console.log('  ╔══════════════════════════════════════════╗');
  console.log('  ║   🎓 INTERNSHIP TRACKER — SERVER READY   ║');
  console.log('  ╠══════════════════════════════════════════╣');
  console.log(`  ║   🚀 Running on  http://localhost:${PORT}    ║`);
  console.log('  ║   📂 Database    ./data/ (JSON files)    ║');
  console.log('  ╠══════════════════════════════════════════╣');
  console.log('  ║   Default Logins:                        ║');
  console.log('  ║   Admin   → admin / 1234                 ║');
  console.log('  ║   Student → student@college.edu          ║');
  console.log('  ║             / student123                 ║');
  console.log('  ╚══════════════════════════════════════════╝');
  console.log('\n');
});
